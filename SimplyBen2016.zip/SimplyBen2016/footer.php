</footer>
<?php wp_footer(); ?>
<script src="/js/masonry.pkgd.min.js"></script>
</body>
</html>